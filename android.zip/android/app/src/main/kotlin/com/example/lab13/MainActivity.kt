package com.example.lab13

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
